// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__GENERIC_LANE_HPP_
#define V2X_MSGS__MSG__GENERIC_LANE_HPP_

#include "v2x_msgs/msg/detail/generic_lane__struct.hpp"
#include "v2x_msgs/msg/detail/generic_lane__builder.hpp"
#include "v2x_msgs/msg/detail/generic_lane__traits.hpp"
#include "v2x_msgs/msg/detail/generic_lane__type_support.hpp"

#endif  // V2X_MSGS__MSG__GENERIC_LANE_HPP_
