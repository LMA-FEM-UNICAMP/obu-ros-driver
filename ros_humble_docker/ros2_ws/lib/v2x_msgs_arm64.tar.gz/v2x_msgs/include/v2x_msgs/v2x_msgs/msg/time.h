// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/Time.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__TIME_H_
#define V2X_MSGS__MSG__TIME_H_

#include "v2x_msgs/msg/detail/time__struct.h"
#include "v2x_msgs/msg/detail/time__functions.h"
#include "v2x_msgs/msg/detail/time__type_support.h"

#endif  // V2X_MSGS__MSG__TIME_H_
