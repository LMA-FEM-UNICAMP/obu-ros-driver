// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/LaneDelimitation.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__LANE_DELIMITATION_H_
#define V2X_MSGS__MSG__LANE_DELIMITATION_H_

#include "v2x_msgs/msg/detail/lane_delimitation__struct.h"
#include "v2x_msgs/msg/detail/lane_delimitation__functions.h"
#include "v2x_msgs/msg/detail/lane_delimitation__type_support.h"

#endif  // V2X_MSGS__MSG__LANE_DELIMITATION_H_
