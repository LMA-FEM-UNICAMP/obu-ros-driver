// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__OBJECT_DIMENSION_VALUE_HPP_
#define V2X_MSGS__MSG__OBJECT_DIMENSION_VALUE_HPP_

#include "v2x_msgs/msg/detail/object_dimension_value__struct.hpp"
#include "v2x_msgs/msg/detail/object_dimension_value__builder.hpp"
#include "v2x_msgs/msg/detail/object_dimension_value__traits.hpp"
#include "v2x_msgs/msg/detail/object_dimension_value__type_support.hpp"

#endif  // V2X_MSGS__MSG__OBJECT_DIMENSION_VALUE_HPP_
