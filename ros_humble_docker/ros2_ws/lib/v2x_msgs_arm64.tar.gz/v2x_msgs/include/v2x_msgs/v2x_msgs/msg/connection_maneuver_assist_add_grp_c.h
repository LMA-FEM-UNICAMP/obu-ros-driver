// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/ConnectionManeuverAssistAddGrpC.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__CONNECTION_MANEUVER_ASSIST_ADD_GRP_C_H_
#define V2X_MSGS__MSG__CONNECTION_MANEUVER_ASSIST_ADD_GRP_C_H_

#include "v2x_msgs/msg/detail/connection_maneuver_assist_add_grp_c__struct.h"
#include "v2x_msgs/msg/detail/connection_maneuver_assist_add_grp_c__functions.h"
#include "v2x_msgs/msg/detail/connection_maneuver_assist_add_grp_c__type_support.h"

#endif  // V2X_MSGS__MSG__CONNECTION_MANEUVER_ASSIST_ADD_GRP_C_H_
