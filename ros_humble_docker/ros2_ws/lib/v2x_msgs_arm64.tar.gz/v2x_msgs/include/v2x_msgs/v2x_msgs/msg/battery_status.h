// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/BatteryStatus.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__BATTERY_STATUS_H_
#define V2X_MSGS__MSG__BATTERY_STATUS_H_

#include "v2x_msgs/msg/detail/battery_status__struct.h"
#include "v2x_msgs/msg/detail/battery_status__functions.h"
#include "v2x_msgs/msg/detail/battery_status__type_support.h"

#endif  // V2X_MSGS__MSG__BATTERY_STATUS_H_
