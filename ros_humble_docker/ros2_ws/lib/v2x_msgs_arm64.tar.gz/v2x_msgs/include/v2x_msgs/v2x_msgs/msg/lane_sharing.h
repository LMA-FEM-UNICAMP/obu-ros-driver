// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/LaneSharing.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__LANE_SHARING_H_
#define V2X_MSGS__MSG__LANE_SHARING_H_

#include "v2x_msgs/msg/detail/lane_sharing__struct.h"
#include "v2x_msgs/msg/detail/lane_sharing__functions.h"
#include "v2x_msgs/msg/detail/lane_sharing__type_support.h"

#endif  // V2X_MSGS__MSG__LANE_SHARING_H_
