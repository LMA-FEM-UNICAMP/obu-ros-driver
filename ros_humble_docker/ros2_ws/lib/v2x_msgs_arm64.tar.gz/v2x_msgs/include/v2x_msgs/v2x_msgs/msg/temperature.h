// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/Temperature.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__TEMPERATURE_H_
#define V2X_MSGS__MSG__TEMPERATURE_H_

#include "v2x_msgs/msg/detail/temperature__struct.h"
#include "v2x_msgs/msg/detail/temperature__functions.h"
#include "v2x_msgs/msg/detail/temperature__type_support.h"

#endif  // V2X_MSGS__MSG__TEMPERATURE_H_
