// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/IviPurpose.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__IVI_PURPOSE_H_
#define V2X_MSGS__MSG__IVI_PURPOSE_H_

#include "v2x_msgs/msg/detail/ivi_purpose__struct.h"
#include "v2x_msgs/msg/detail/ivi_purpose__functions.h"
#include "v2x_msgs/msg/detail/ivi_purpose__type_support.h"

#endif  // V2X_MSGS__MSG__IVI_PURPOSE_H_
