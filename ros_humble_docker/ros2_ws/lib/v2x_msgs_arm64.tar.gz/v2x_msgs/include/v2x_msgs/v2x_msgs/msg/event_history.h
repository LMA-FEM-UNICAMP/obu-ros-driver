// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/EventHistory.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__EVENT_HISTORY_H_
#define V2X_MSGS__MSG__EVENT_HISTORY_H_

#include "v2x_msgs/msg/detail/event_history__struct.h"
#include "v2x_msgs/msg/detail/event_history__functions.h"
#include "v2x_msgs/msg/detail/event_history__type_support.h"

#endif  // V2X_MSGS__MSG__EVENT_HISTORY_H_
