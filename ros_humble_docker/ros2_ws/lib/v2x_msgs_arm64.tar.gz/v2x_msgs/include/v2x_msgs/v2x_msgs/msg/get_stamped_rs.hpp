// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__GET_STAMPED_RS_HPP_
#define V2X_MSGS__MSG__GET_STAMPED_RS_HPP_

#include "v2x_msgs/msg/detail/get_stamped_rs__struct.hpp"
#include "v2x_msgs/msg/detail/get_stamped_rs__builder.hpp"
#include "v2x_msgs/msg/detail/get_stamped_rs__traits.hpp"
#include "v2x_msgs/msg/detail/get_stamped_rs__type_support.hpp"

#endif  // V2X_MSGS__MSG__GET_STAMPED_RS_HPP_
