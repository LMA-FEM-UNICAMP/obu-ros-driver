// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/RefPointId.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__REF_POINT_ID_H_
#define V2X_MSGS__MSG__REF_POINT_ID_H_

#include "v2x_msgs/msg/detail/ref_point_id__struct.h"
#include "v2x_msgs/msg/detail/ref_point_id__functions.h"
#include "v2x_msgs/msg/detail/ref_point_id__type_support.h"

#endif  // V2X_MSGS__MSG__REF_POINT_ID_H_
