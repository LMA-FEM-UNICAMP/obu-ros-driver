// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/CurvatureConfidence.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__CURVATURE_CONFIDENCE_H_
#define V2X_MSGS__MSG__CURVATURE_CONFIDENCE_H_

#include "v2x_msgs/msg/detail/curvature_confidence__struct.h"
#include "v2x_msgs/msg/detail/curvature_confidence__functions.h"
#include "v2x_msgs/msg/detail/curvature_confidence__type_support.h"

#endif  // V2X_MSGS__MSG__CURVATURE_CONFIDENCE_H_
