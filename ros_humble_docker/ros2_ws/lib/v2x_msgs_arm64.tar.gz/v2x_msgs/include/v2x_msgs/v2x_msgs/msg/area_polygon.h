// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/AreaPolygon.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__AREA_POLYGON_H_
#define V2X_MSGS__MSG__AREA_POLYGON_H_

#include "v2x_msgs/msg/detail/area_polygon__struct.h"
#include "v2x_msgs/msg/detail/area_polygon__functions.h"
#include "v2x_msgs/msg/detail/area_polygon__type_support.h"

#endif  // V2X_MSGS__MSG__AREA_POLYGON_H_
