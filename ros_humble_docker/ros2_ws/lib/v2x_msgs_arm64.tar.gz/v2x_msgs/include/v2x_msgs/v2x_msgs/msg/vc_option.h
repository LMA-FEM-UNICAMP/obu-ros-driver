// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/VcOption.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__VC_OPTION_H_
#define V2X_MSGS__MSG__VC_OPTION_H_

#include "v2x_msgs/msg/detail/vc_option__struct.h"
#include "v2x_msgs/msg/detail/vc_option__functions.h"
#include "v2x_msgs/msg/detail/vc_option__type_support.h"

#endif  // V2X_MSGS__MSG__VC_OPTION_H_
