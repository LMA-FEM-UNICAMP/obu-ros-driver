// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/MinuteOfTheYear.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__MINUTE_OF_THE_YEAR_H_
#define V2X_MSGS__MSG__MINUTE_OF_THE_YEAR_H_

#include "v2x_msgs/msg/detail/minute_of_the_year__struct.h"
#include "v2x_msgs/msg/detail/minute_of_the_year__functions.h"
#include "v2x_msgs/msg/detail/minute_of_the_year__type_support.h"

#endif  // V2X_MSGS__MSG__MINUTE_OF_THE_YEAR_H_
