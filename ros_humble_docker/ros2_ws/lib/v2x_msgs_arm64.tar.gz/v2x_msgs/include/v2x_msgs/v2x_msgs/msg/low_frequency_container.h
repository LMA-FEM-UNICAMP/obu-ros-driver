// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/LowFrequencyContainer.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__LOW_FREQUENCY_CONTAINER_H_
#define V2X_MSGS__MSG__LOW_FREQUENCY_CONTAINER_H_

#include "v2x_msgs/msg/detail/low_frequency_container__struct.h"
#include "v2x_msgs/msg/detail/low_frequency_container__functions.h"
#include "v2x_msgs/msg/detail/low_frequency_container__type_support.h"

#endif  // V2X_MSGS__MSG__LOW_FREQUENCY_CONTAINER_H_
