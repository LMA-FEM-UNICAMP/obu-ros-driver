// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/VehicleLicencePlateNumber.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__VEHICLE_LICENCE_PLATE_NUMBER_H_
#define V2X_MSGS__MSG__VEHICLE_LICENCE_PLATE_NUMBER_H_

#include "v2x_msgs/msg/detail/vehicle_licence_plate_number__struct.h"
#include "v2x_msgs/msg/detail/vehicle_licence_plate_number__functions.h"
#include "v2x_msgs/msg/detail/vehicle_licence_plate_number__type_support.h"

#endif  // V2X_MSGS__MSG__VEHICLE_LICENCE_PLATE_NUMBER_H_
