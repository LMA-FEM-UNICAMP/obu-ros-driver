// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/EventPoint.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__EVENT_POINT_H_
#define V2X_MSGS__MSG__EVENT_POINT_H_

#include "v2x_msgs/msg/detail/event_point__struct.h"
#include "v2x_msgs/msg/detail/event_point__functions.h"
#include "v2x_msgs/msg/detail/event_point__type_support.h"

#endif  // V2X_MSGS__MSG__EVENT_POINT_H_
