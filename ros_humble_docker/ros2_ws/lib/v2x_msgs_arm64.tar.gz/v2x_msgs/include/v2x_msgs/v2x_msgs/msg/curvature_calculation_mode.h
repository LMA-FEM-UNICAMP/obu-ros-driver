// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/CurvatureCalculationMode.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__CURVATURE_CALCULATION_MODE_H_
#define V2X_MSGS__MSG__CURVATURE_CALCULATION_MODE_H_

#include "v2x_msgs/msg/detail/curvature_calculation_mode__struct.h"
#include "v2x_msgs/msg/detail/curvature_calculation_mode__functions.h"
#include "v2x_msgs/msg/detail/curvature_calculation_mode__type_support.h"

#endif  // V2X_MSGS__MSG__CURVATURE_CALCULATION_MODE_H_
