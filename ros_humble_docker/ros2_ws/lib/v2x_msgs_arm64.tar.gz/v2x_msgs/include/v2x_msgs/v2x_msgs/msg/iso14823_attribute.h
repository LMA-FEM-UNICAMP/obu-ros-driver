// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/ISO14823Attribute.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__ISO14823_ATTRIBUTE_H_
#define V2X_MSGS__MSG__ISO14823_ATTRIBUTE_H_

#include "v2x_msgs/msg/detail/iso14823_attribute__struct.h"
#include "v2x_msgs/msg/detail/iso14823_attribute__functions.h"
#include "v2x_msgs/msg/detail/iso14823_attribute__type_support.h"

#endif  // V2X_MSGS__MSG__ISO14823_ATTRIBUTE_H_
