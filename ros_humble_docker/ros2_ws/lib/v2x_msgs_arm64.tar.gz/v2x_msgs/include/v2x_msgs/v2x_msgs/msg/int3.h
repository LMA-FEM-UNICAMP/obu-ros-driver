// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/Int3.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__INT3_H_
#define V2X_MSGS__MSG__INT3_H_

#include "v2x_msgs/msg/detail/int3__struct.h"
#include "v2x_msgs/msg/detail/int3__functions.h"
#include "v2x_msgs/msg/detail/int3__type_support.h"

#endif  // V2X_MSGS__MSG__INT3_H_
