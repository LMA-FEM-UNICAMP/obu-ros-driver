// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__D_OFFSET_HPP_
#define V2X_MSGS__MSG__D_OFFSET_HPP_

#include "v2x_msgs/msg/detail/d_offset__struct.hpp"
#include "v2x_msgs/msg/detail/d_offset__builder.hpp"
#include "v2x_msgs/msg/detail/d_offset__traits.hpp"
#include "v2x_msgs/msg/detail/d_offset__type_support.hpp"

#endif  // V2X_MSGS__MSG__D_OFFSET_HPP_
