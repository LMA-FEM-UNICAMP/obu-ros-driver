// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__PEDESTRIAN_BICYCLE_DETECT_HPP_
#define V2X_MSGS__MSG__PEDESTRIAN_BICYCLE_DETECT_HPP_

#include "v2x_msgs/msg/detail/pedestrian_bicycle_detect__struct.hpp"
#include "v2x_msgs/msg/detail/pedestrian_bicycle_detect__builder.hpp"
#include "v2x_msgs/msg/detail/pedestrian_bicycle_detect__traits.hpp"
#include "v2x_msgs/msg/detail/pedestrian_bicycle_detect__type_support.hpp"

#endif  // V2X_MSGS__MSG__PEDESTRIAN_BICYCLE_DETECT_HPP_
