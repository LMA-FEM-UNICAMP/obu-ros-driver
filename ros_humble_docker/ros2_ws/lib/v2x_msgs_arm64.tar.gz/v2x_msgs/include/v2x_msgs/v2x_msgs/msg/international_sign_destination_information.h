// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/InternationalSignDestinationInformation.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__INTERNATIONAL_SIGN_DESTINATION_INFORMATION_H_
#define V2X_MSGS__MSG__INTERNATIONAL_SIGN_DESTINATION_INFORMATION_H_

#include "v2x_msgs/msg/detail/international_sign_destination_information__struct.h"
#include "v2x_msgs/msg/detail/international_sign_destination_information__functions.h"
#include "v2x_msgs/msg/detail/international_sign_destination_information__type_support.h"

#endif  // V2X_MSGS__MSG__INTERNATIONAL_SIGN_DESTINATION_INFORMATION_H_
