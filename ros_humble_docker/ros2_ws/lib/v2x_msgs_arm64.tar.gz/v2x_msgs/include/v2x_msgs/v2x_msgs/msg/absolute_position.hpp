// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__ABSOLUTE_POSITION_HPP_
#define V2X_MSGS__MSG__ABSOLUTE_POSITION_HPP_

#include "v2x_msgs/msg/detail/absolute_position__struct.hpp"
#include "v2x_msgs/msg/detail/absolute_position__builder.hpp"
#include "v2x_msgs/msg/detail/absolute_position__traits.hpp"
#include "v2x_msgs/msg/detail/absolute_position__type_support.hpp"

#endif  // V2X_MSGS__MSG__ABSOLUTE_POSITION_HPP_
