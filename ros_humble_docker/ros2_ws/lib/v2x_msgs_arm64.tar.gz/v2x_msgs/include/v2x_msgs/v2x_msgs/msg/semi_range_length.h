// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/SemiRangeLength.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__SEMI_RANGE_LENGTH_H_
#define V2X_MSGS__MSG__SEMI_RANGE_LENGTH_H_

#include "v2x_msgs/msg/detail/semi_range_length__struct.h"
#include "v2x_msgs/msg/detail/semi_range_length__functions.h"
#include "v2x_msgs/msg/detail/semi_range_length__type_support.h"

#endif  // V2X_MSGS__MSG__SEMI_RANGE_LENGTH_H_
