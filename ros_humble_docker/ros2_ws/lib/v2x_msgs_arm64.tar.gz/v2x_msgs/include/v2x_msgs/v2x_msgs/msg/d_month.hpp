// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__D_MONTH_HPP_
#define V2X_MSGS__MSG__D_MONTH_HPP_

#include "v2x_msgs/msg/detail/d_month__struct.hpp"
#include "v2x_msgs/msg/detail/d_month__builder.hpp"
#include "v2x_msgs/msg/detail/d_month__traits.hpp"
#include "v2x_msgs/msg/detail/d_month__type_support.hpp"

#endif  // V2X_MSGS__MSG__D_MONTH_HPP_
