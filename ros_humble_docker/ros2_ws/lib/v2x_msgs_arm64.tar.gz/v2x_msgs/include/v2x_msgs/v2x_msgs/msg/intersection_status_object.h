// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/IntersectionStatusObject.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__INTERSECTION_STATUS_OBJECT_H_
#define V2X_MSGS__MSG__INTERSECTION_STATUS_OBJECT_H_

#include "v2x_msgs/msg/detail/intersection_status_object__struct.h"
#include "v2x_msgs/msg/detail/intersection_status_object__functions.h"
#include "v2x_msgs/msg/detail/intersection_status_object__type_support.h"

#endif  // V2X_MSGS__MSG__INTERSECTION_STATUS_OBJECT_H_
