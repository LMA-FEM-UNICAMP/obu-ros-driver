// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__DANGEROUS_GOODS_BASIC_HPP_
#define V2X_MSGS__MSG__DANGEROUS_GOODS_BASIC_HPP_

#include "v2x_msgs/msg/detail/dangerous_goods_basic__struct.hpp"
#include "v2x_msgs/msg/detail/dangerous_goods_basic__builder.hpp"
#include "v2x_msgs/msg/detail/dangerous_goods_basic__traits.hpp"
#include "v2x_msgs/msg/detail/dangerous_goods_basic__type_support.hpp"

#endif  // V2X_MSGS__MSG__DANGEROUS_GOODS_BASIC_HPP_
