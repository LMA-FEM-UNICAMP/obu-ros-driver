// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/RegLaneDataAttribute.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__REG_LANE_DATA_ATTRIBUTE_H_
#define V2X_MSGS__MSG__REG_LANE_DATA_ATTRIBUTE_H_

#include "v2x_msgs/msg/detail/reg_lane_data_attribute__struct.h"
#include "v2x_msgs/msg/detail/reg_lane_data_attribute__functions.h"
#include "v2x_msgs/msg/detail/reg_lane_data_attribute__type_support.h"

#endif  // V2X_MSGS__MSG__REG_LANE_DATA_ATTRIBUTE_H_
