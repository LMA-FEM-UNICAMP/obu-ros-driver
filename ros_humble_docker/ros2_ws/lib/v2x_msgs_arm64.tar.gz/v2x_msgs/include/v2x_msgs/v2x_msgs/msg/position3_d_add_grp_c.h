// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/Position3DAddGrpC.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__POSITION3_D_ADD_GRP_C_H_
#define V2X_MSGS__MSG__POSITION3_D_ADD_GRP_C_H_

#include "v2x_msgs/msg/detail/position3_d_add_grp_c__struct.h"
#include "v2x_msgs/msg/detail/position3_d_add_grp_c__functions.h"
#include "v2x_msgs/msg/detail/position3_d_add_grp_c__type_support.h"

#endif  // V2X_MSGS__MSG__POSITION3_D_ADD_GRP_C_H_
