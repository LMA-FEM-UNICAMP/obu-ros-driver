// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/DescriptiveName.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__DESCRIPTIVE_NAME_H_
#define V2X_MSGS__MSG__DESCRIPTIVE_NAME_H_

#include "v2x_msgs/msg/detail/descriptive_name__struct.h"
#include "v2x_msgs/msg/detail/descriptive_name__functions.h"
#include "v2x_msgs/msg/detail/descriptive_name__type_support.h"

#endif  // V2X_MSGS__MSG__DESCRIPTIVE_NAME_H_
