// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__LANE_ATTRIBUTES_PARKING_HPP_
#define V2X_MSGS__MSG__LANE_ATTRIBUTES_PARKING_HPP_

#include "v2x_msgs/msg/detail/lane_attributes_parking__struct.hpp"
#include "v2x_msgs/msg/detail/lane_attributes_parking__builder.hpp"
#include "v2x_msgs/msg/detail/lane_attributes_parking__traits.hpp"
#include "v2x_msgs/msg/detail/lane_attributes_parking__type_support.hpp"

#endif  // V2X_MSGS__MSG__LANE_ATTRIBUTES_PARKING_HPP_
