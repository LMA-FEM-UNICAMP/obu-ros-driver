// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/DangerousEndOfQueueSubCauseCode.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__DANGEROUS_END_OF_QUEUE_SUB_CAUSE_CODE_H_
#define V2X_MSGS__MSG__DANGEROUS_END_OF_QUEUE_SUB_CAUSE_CODE_H_

#include "v2x_msgs/msg/detail/dangerous_end_of_queue_sub_cause_code__struct.h"
#include "v2x_msgs/msg/detail/dangerous_end_of_queue_sub_cause_code__functions.h"
#include "v2x_msgs/msg/detail/dangerous_end_of_queue_sub_cause_code__type_support.h"

#endif  // V2X_MSGS__MSG__DANGEROUS_END_OF_QUEUE_SUB_CAUSE_CODE_H_
