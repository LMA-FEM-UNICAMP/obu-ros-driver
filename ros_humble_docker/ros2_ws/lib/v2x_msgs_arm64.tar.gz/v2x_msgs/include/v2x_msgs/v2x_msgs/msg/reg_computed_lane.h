// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/RegComputedLane.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__REG_COMPUTED_LANE_H_
#define V2X_MSGS__MSG__REG_COMPUTED_LANE_H_

#include "v2x_msgs/msg/detail/reg_computed_lane__struct.h"
#include "v2x_msgs/msg/detail/reg_computed_lane__functions.h"
#include "v2x_msgs/msg/detail/reg_computed_lane__type_support.h"

#endif  // V2X_MSGS__MSG__REG_COMPUTED_LANE_H_
