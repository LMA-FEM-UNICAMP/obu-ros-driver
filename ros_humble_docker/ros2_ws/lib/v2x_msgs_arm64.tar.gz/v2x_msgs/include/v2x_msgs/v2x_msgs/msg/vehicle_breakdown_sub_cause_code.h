// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/VehicleBreakdownSubCauseCode.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__VEHICLE_BREAKDOWN_SUB_CAUSE_CODE_H_
#define V2X_MSGS__MSG__VEHICLE_BREAKDOWN_SUB_CAUSE_CODE_H_

#include "v2x_msgs/msg/detail/vehicle_breakdown_sub_cause_code__struct.h"
#include "v2x_msgs/msg/detail/vehicle_breakdown_sub_cause_code__functions.h"
#include "v2x_msgs/msg/detail/vehicle_breakdown_sub_cause_code__type_support.h"

#endif  // V2X_MSGS__MSG__VEHICLE_BREAKDOWN_SUB_CAUSE_CODE_H_
