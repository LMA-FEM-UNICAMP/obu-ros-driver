// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/PathPoint.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__PATH_POINT_H_
#define V2X_MSGS__MSG__PATH_POINT_H_

#include "v2x_msgs/msg/detail/path_point__struct.h"
#include "v2x_msgs/msg/detail/path_point__functions.h"
#include "v2x_msgs/msg/detail/path_point__type_support.h"

#endif  // V2X_MSGS__MSG__PATH_POINT_H_
