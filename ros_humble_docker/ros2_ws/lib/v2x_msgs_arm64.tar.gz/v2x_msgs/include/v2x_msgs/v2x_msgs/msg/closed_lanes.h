// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/ClosedLanes.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__CLOSED_LANES_H_
#define V2X_MSGS__MSG__CLOSED_LANES_H_

#include "v2x_msgs/msg/detail/closed_lanes__struct.h"
#include "v2x_msgs/msg/detail/closed_lanes__functions.h"
#include "v2x_msgs/msg/detail/closed_lanes__type_support.h"

#endif  // V2X_MSGS__MSG__CLOSED_LANES_H_
