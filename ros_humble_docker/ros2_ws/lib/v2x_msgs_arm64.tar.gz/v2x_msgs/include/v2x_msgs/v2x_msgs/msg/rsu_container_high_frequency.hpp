// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__RSU_CONTAINER_HIGH_FREQUENCY_HPP_
#define V2X_MSGS__MSG__RSU_CONTAINER_HIGH_FREQUENCY_HPP_

#include "v2x_msgs/msg/detail/rsu_container_high_frequency__struct.hpp"
#include "v2x_msgs/msg/detail/rsu_container_high_frequency__builder.hpp"
#include "v2x_msgs/msg/detail/rsu_container_high_frequency__traits.hpp"
#include "v2x_msgs/msg/detail/rsu_container_high_frequency__type_support.hpp"

#endif  // V2X_MSGS__MSG__RSU_CONTAINER_HIGH_FREQUENCY_HPP_
