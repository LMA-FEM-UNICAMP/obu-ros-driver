// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/PosFrontAx.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__POS_FRONT_AX_H_
#define V2X_MSGS__MSG__POS_FRONT_AX_H_

#include "v2x_msgs/msg/detail/pos_front_ax__struct.h"
#include "v2x_msgs/msg/detail/pos_front_ax__functions.h"
#include "v2x_msgs/msg/detail/pos_front_ax__type_support.h"

#endif  // V2X_MSGS__MSG__POS_FRONT_AX_H_
