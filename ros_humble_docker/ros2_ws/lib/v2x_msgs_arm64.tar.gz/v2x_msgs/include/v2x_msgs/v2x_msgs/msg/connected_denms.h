// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/ConnectedDenms.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__CONNECTED_DENMS_H_
#define V2X_MSGS__MSG__CONNECTED_DENMS_H_

#include "v2x_msgs/msg/detail/connected_denms__struct.h"
#include "v2x_msgs/msg/detail/connected_denms__functions.h"
#include "v2x_msgs/msg/detail/connected_denms__type_support.h"

#endif  // V2X_MSGS__MSG__CONNECTED_DENMS_H_
