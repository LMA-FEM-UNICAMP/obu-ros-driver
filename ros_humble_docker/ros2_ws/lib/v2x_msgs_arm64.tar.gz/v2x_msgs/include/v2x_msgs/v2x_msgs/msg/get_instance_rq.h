// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/GetInstanceRq.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__GET_INSTANCE_RQ_H_
#define V2X_MSGS__MSG__GET_INSTANCE_RQ_H_

#include "v2x_msgs/msg/detail/get_instance_rq__struct.h"
#include "v2x_msgs/msg/detail/get_instance_rq__functions.h"
#include "v2x_msgs/msg/detail/get_instance_rq__type_support.h"

#endif  // V2X_MSGS__MSG__GET_INSTANCE_RQ_H_
