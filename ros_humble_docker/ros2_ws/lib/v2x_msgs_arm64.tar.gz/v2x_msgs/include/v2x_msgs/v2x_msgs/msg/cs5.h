// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/CS5.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__CS5_H_
#define V2X_MSGS__MSG__CS5_H_

#include "v2x_msgs/msg/detail/cs5__struct.h"
#include "v2x_msgs/msg/detail/cs5__functions.h"
#include "v2x_msgs/msg/detail/cs5__type_support.h"

#endif  // V2X_MSGS__MSG__CS5_H_
