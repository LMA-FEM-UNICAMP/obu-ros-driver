// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/NodeXY20b.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__NODE_XY20B_H_
#define V2X_MSGS__MSG__NODE_XY20B_H_

#include "v2x_msgs/msg/detail/node_xy20b__struct.h"
#include "v2x_msgs/msg/detail/node_xy20b__functions.h"
#include "v2x_msgs/msg/detail/node_xy20b__type_support.h"

#endif  // V2X_MSGS__MSG__NODE_XY20B_H_
