// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/RxInfo.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__RX_INFO_H_
#define V2X_MSGS__MSG__RX_INFO_H_

#include "v2x_msgs/msg/detail/rx_info__struct.h"
#include "v2x_msgs/msg/detail/rx_info__functions.h"
#include "v2x_msgs/msg/detail/rx_info__type_support.h"

#endif  // V2X_MSGS__MSG__RX_INFO_H_
