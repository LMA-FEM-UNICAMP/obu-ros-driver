// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/NodeLink.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__NODE_LINK_H_
#define V2X_MSGS__MSG__NODE_LINK_H_

#include "v2x_msgs/msg/detail/node_link__struct.h"
#include "v2x_msgs/msg/detail/node_link__functions.h"
#include "v2x_msgs/msg/detail/node_link__type_support.h"

#endif  // V2X_MSGS__MSG__NODE_LINK_H_
