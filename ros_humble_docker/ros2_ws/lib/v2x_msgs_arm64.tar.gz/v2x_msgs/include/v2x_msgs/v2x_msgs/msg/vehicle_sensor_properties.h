// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/VehicleSensorProperties.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__VEHICLE_SENSOR_PROPERTIES_H_
#define V2X_MSGS__MSG__VEHICLE_SENSOR_PROPERTIES_H_

#include "v2x_msgs/msg/detail/vehicle_sensor_properties__struct.h"
#include "v2x_msgs/msg/detail/vehicle_sensor_properties__functions.h"
#include "v2x_msgs/msg/detail/vehicle_sensor_properties__type_support.h"

#endif  // V2X_MSGS__MSG__VEHICLE_SENSOR_PROPERTIES_H_
