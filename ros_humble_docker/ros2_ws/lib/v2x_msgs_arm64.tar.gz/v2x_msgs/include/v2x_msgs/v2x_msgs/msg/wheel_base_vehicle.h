// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/WheelBaseVehicle.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__WHEEL_BASE_VEHICLE_H_
#define V2X_MSGS__MSG__WHEEL_BASE_VEHICLE_H_

#include "v2x_msgs/msg/detail/wheel_base_vehicle__struct.h"
#include "v2x_msgs/msg/detail/wheel_base_vehicle__functions.h"
#include "v2x_msgs/msg/detail/wheel_base_vehicle__type_support.h"

#endif  // V2X_MSGS__MSG__WHEEL_BASE_VEHICLE_H_
