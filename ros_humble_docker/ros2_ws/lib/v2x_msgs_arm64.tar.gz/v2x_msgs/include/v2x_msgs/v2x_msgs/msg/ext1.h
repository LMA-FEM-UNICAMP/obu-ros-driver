// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/Ext1.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__EXT1_H_
#define V2X_MSGS__MSG__EXT1_H_

#include "v2x_msgs/msg/detail/ext1__struct.h"
#include "v2x_msgs/msg/detail/ext1__functions.h"
#include "v2x_msgs/msg/detail/ext1__type_support.h"

#endif  // V2X_MSGS__MSG__EXT1_H_
