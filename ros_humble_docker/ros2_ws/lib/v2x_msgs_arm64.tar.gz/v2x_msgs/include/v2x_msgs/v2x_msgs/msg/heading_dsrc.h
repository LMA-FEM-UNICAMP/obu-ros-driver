// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/HeadingDSRC.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__HEADING_DSRC_H_
#define V2X_MSGS__MSG__HEADING_DSRC_H_

#include "v2x_msgs/msg/detail/heading_dsrc__struct.h"
#include "v2x_msgs/msg/detail/heading_dsrc__functions.h"
#include "v2x_msgs/msg/detail/heading_dsrc__type_support.h"

#endif  // V2X_MSGS__MSG__HEADING_DSRC_H_
