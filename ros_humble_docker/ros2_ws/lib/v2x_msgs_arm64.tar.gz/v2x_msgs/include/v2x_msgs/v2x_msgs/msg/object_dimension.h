// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/ObjectDimension.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__OBJECT_DIMENSION_H_
#define V2X_MSGS__MSG__OBJECT_DIMENSION_H_

#include "v2x_msgs/msg/detail/object_dimension__struct.h"
#include "v2x_msgs/msg/detail/object_dimension__functions.h"
#include "v2x_msgs/msg/detail/object_dimension__type_support.h"

#endif  // V2X_MSGS__MSG__OBJECT_DIMENSION_H_
