// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/ActualNumberOfPassengers.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__ACTUAL_NUMBER_OF_PASSENGERS_H_
#define V2X_MSGS__MSG__ACTUAL_NUMBER_OF_PASSENGERS_H_

#include "v2x_msgs/msg/detail/actual_number_of_passengers__struct.h"
#include "v2x_msgs/msg/detail/actual_number_of_passengers__functions.h"
#include "v2x_msgs/msg/detail/actual_number_of_passengers__type_support.h"

#endif  // V2X_MSGS__MSG__ACTUAL_NUMBER_OF_PASSENGERS_H_
