// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/DecapStatus.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__DECAP_STATUS_H_
#define V2X_MSGS__MSG__DECAP_STATUS_H_

#include "v2x_msgs/msg/detail/decap_status__struct.h"
#include "v2x_msgs/msg/detail/decap_status__functions.h"
#include "v2x_msgs/msg/detail/decap_status__type_support.h"

#endif  // V2X_MSGS__MSG__DECAP_STATUS_H_
