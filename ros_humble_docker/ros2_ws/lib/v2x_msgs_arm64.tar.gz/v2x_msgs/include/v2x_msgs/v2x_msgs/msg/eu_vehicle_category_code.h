// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/EuVehicleCategoryCode.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__EU_VEHICLE_CATEGORY_CODE_H_
#define V2X_MSGS__MSG__EU_VEHICLE_CATEGORY_CODE_H_

#include "v2x_msgs/msg/detail/eu_vehicle_category_code__struct.h"
#include "v2x_msgs/msg/detail/eu_vehicle_category_code__functions.h"
#include "v2x_msgs/msg/detail/eu_vehicle_category_code__type_support.h"

#endif  // V2X_MSGS__MSG__EU_VEHICLE_CATEGORY_CODE_H_
