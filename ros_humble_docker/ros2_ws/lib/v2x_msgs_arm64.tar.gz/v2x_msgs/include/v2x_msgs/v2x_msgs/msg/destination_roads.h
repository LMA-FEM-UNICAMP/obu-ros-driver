// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/DestinationRoads.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__DESTINATION_ROADS_H_
#define V2X_MSGS__MSG__DESTINATION_ROADS_H_

#include "v2x_msgs/msg/detail/destination_roads__struct.h"
#include "v2x_msgs/msg/detail/destination_roads__functions.h"
#include "v2x_msgs/msg/detail/destination_roads__type_support.h"

#endif  // V2X_MSGS__MSG__DESTINATION_ROADS_H_
