// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/InternationalSignDistanceBetweenVehicles.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__INTERNATIONAL_SIGN_DISTANCE_BETWEEN_VEHICLES_H_
#define V2X_MSGS__MSG__INTERNATIONAL_SIGN_DISTANCE_BETWEEN_VEHICLES_H_

#include "v2x_msgs/msg/detail/international_sign_distance_between_vehicles__struct.h"
#include "v2x_msgs/msg/detail/international_sign_distance_between_vehicles__functions.h"
#include "v2x_msgs/msg/detail/international_sign_distance_between_vehicles__type_support.h"

#endif  // V2X_MSGS__MSG__INTERNATIONAL_SIGN_DISTANCE_BETWEEN_VEHICLES_H_
