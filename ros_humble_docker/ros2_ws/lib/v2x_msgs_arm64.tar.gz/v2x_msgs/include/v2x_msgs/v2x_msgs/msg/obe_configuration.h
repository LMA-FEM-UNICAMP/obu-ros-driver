// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/ObeConfiguration.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__OBE_CONFIGURATION_H_
#define V2X_MSGS__MSG__OBE_CONFIGURATION_H_

#include "v2x_msgs/msg/detail/obe_configuration__struct.h"
#include "v2x_msgs/msg/detail/obe_configuration__functions.h"
#include "v2x_msgs/msg/detail/obe_configuration__type_support.h"

#endif  // V2X_MSGS__MSG__OBE_CONFIGURATION_H_
