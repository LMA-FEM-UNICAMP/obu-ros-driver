// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/VehicleCharacteristicsList.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__VEHICLE_CHARACTERISTICS_LIST_H_
#define V2X_MSGS__MSG__VEHICLE_CHARACTERISTICS_LIST_H_

#include "v2x_msgs/msg/detail/vehicle_characteristics_list__struct.h"
#include "v2x_msgs/msg/detail/vehicle_characteristics_list__functions.h"
#include "v2x_msgs/msg/detail/vehicle_characteristics_list__type_support.h"

#endif  // V2X_MSGS__MSG__VEHICLE_CHARACTERISTICS_LIST_H_
