// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/LaneDirection.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__LANE_DIRECTION_H_
#define V2X_MSGS__MSG__LANE_DIRECTION_H_

#include "v2x_msgs/msg/detail/lane_direction__struct.h"
#include "v2x_msgs/msg/detail/lane_direction__functions.h"
#include "v2x_msgs/msg/detail/lane_direction__type_support.h"

#endif  // V2X_MSGS__MSG__LANE_DIRECTION_H_
