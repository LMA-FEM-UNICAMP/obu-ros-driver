// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/ConstraintTextLines2.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__CONSTRAINT_TEXT_LINES2_H_
#define V2X_MSGS__MSG__CONSTRAINT_TEXT_LINES2_H_

#include "v2x_msgs/msg/detail/constraint_text_lines2__struct.h"
#include "v2x_msgs/msg/detail/constraint_text_lines2__functions.h"
#include "v2x_msgs/msg/detail/constraint_text_lines2__type_support.h"

#endif  // V2X_MSGS__MSG__CONSTRAINT_TEXT_LINES2_H_
