// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/ItsAID.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__ITS_AID_H_
#define V2X_MSGS__MSG__ITS_AID_H_

#include "v2x_msgs/msg/detail/its_aid__struct.h"
#include "v2x_msgs/msg/detail/its_aid__functions.h"
#include "v2x_msgs/msg/detail/its_aid__type_support.h"

#endif  // V2X_MSGS__MSG__ITS_AID_H_
