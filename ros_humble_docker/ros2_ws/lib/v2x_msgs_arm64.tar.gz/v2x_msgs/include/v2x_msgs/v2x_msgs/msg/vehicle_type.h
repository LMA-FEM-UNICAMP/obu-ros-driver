// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/VehicleType.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__VEHICLE_TYPE_H_
#define V2X_MSGS__MSG__VEHICLE_TYPE_H_

#include "v2x_msgs/msg/detail/vehicle_type__struct.h"
#include "v2x_msgs/msg/detail/vehicle_type__functions.h"
#include "v2x_msgs/msg/detail/vehicle_type__type_support.h"

#endif  // V2X_MSGS__MSG__VEHICLE_TYPE_H_
