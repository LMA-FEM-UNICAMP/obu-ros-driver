// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/IviIdentificationNumbers.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__IVI_IDENTIFICATION_NUMBERS_H_
#define V2X_MSGS__MSG__IVI_IDENTIFICATION_NUMBERS_H_

#include "v2x_msgs/msg/detail/ivi_identification_numbers__struct.h"
#include "v2x_msgs/msg/detail/ivi_identification_numbers__functions.h"
#include "v2x_msgs/msg/detail/ivi_identification_numbers__type_support.h"

#endif  // V2X_MSGS__MSG__IVI_IDENTIFICATION_NUMBERS_H_
