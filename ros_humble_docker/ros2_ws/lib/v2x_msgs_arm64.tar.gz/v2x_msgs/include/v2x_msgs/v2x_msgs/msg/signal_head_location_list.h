// generated from rosidl_generator_c/resource/idl.h.em
// with input from v2x_msgs:msg/SignalHeadLocationList.idl
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__SIGNAL_HEAD_LOCATION_LIST_H_
#define V2X_MSGS__MSG__SIGNAL_HEAD_LOCATION_LIST_H_

#include "v2x_msgs/msg/detail/signal_head_location_list__struct.h"
#include "v2x_msgs/msg/detail/signal_head_location_list__functions.h"
#include "v2x_msgs/msg/detail/signal_head_location_list__type_support.h"

#endif  // V2X_MSGS__MSG__SIGNAL_HEAD_LOCATION_LIST_H_
