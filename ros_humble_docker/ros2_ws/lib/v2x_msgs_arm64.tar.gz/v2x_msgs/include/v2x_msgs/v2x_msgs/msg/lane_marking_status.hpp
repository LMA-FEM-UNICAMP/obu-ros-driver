// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef V2X_MSGS__MSG__LANE_MARKING_STATUS_HPP_
#define V2X_MSGS__MSG__LANE_MARKING_STATUS_HPP_

#include "v2x_msgs/msg/detail/lane_marking_status__struct.hpp"
#include "v2x_msgs/msg/detail/lane_marking_status__builder.hpp"
#include "v2x_msgs/msg/detail/lane_marking_status__traits.hpp"
#include "v2x_msgs/msg/detail/lane_marking_status__type_support.hpp"

#endif  // V2X_MSGS__MSG__LANE_MARKING_STATUS_HPP_
